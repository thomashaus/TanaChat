-- ============================================
-- TanaChat Database Schema
-- PostgreSQL 14+
-- ============================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS pg_trgm;  -- For fuzzy text search

-- ============================================
-- NODES TABLE: Core entity storage
-- ============================================
CREATE TABLE IF NOT EXISTS nodes (
    -- Identity
    id TEXT PRIMARY KEY,
    
    -- Core properties
    doc_type TEXT,
    name TEXT,
    description TEXT,
    
    -- Relationships
    owner_id TEXT,
    meta_node_id TEXT,
    source_id TEXT,
    
    -- Timestamps (milliseconds since epoch)
    created BIGINT,
    
    -- Flexible storage for Tana-specific props
    props JSONB,
    modified_ts JSONB,
    touch_counts JSONB,
    
    -- Sync tracking
    last_seen_txid BIGINT NOT NULL,
    last_synced_at TIMESTAMPTZ DEFAULT NOW(),
    is_deleted BOOLEAN DEFAULT FALSE,
    sync_hash TEXT NOT NULL,
    
    -- Full-text search vector (auto-generated)
    search_vector TSVECTOR GENERATED ALWAYS AS (
        to_tsvector('english', COALESCE(name, '') || ' ' || COALESCE(description, ''))
    ) STORED,
    
    -- Foreign keys (deferred to allow circular references)
    CONSTRAINT fk_owner FOREIGN KEY (owner_id) 
        REFERENCES nodes(id) DEFERRABLE INITIALLY DEFERRED,
    CONSTRAINT fk_meta FOREIGN KEY (meta_node_id) 
        REFERENCES nodes(id) DEFERRABLE INITIALLY DEFERRED,
    CONSTRAINT fk_source FOREIGN KEY (source_id) 
        REFERENCES nodes(id) DEFERRABLE INITIALLY DEFERRED
);

-- ============================================
-- NODE_CHILDREN: Hierarchical relationships
-- ============================================
CREATE TABLE IF NOT EXISTS node_children (
    parent_id TEXT NOT NULL,
    child_id TEXT NOT NULL,
    position INTEGER NOT NULL,
    
    PRIMARY KEY (parent_id, child_id),
    
    CONSTRAINT fk_parent FOREIGN KEY (parent_id) 
        REFERENCES nodes(id) ON DELETE CASCADE,
    CONSTRAINT fk_child FOREIGN KEY (child_id) 
        REFERENCES nodes(id) ON DELETE CASCADE
);

-- ============================================
-- SUPERTAGS: Denormalized for fast lookups
-- ============================================
CREATE TABLE IF NOT EXISTS supertags (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    base_type TEXT,
    field_ids TEXT[],
    props JSONB,
    
    CONSTRAINT supertags_name_unique UNIQUE (name),
    CONSTRAINT fk_supertag_node FOREIGN KEY (id) 
        REFERENCES nodes(id) ON DELETE CASCADE
);

-- ============================================
-- FIELDS: Field definitions
-- ============================================
CREATE TABLE IF NOT EXISTS fields (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    data_type TEXT,
    value_constraint TEXT,
    options TEXT[],
    props JSONB,
    
    CONSTRAINT fk_field_node FOREIGN KEY (id) 
        REFERENCES nodes(id) ON DELETE CASCADE
);

-- ============================================
-- SYNC_LOG: Audit trail
-- ============================================
CREATE TABLE IF NOT EXISTS sync_log (
    sync_id SERIAL PRIMARY KEY,
    export_txid BIGINT NOT NULL,
    export_filename TEXT,
    nodes_added INTEGER DEFAULT 0,
    nodes_updated INTEGER DEFAULT 0,
    nodes_deleted INTEGER DEFAULT 0,
    nodes_unchanged INTEGER DEFAULT 0,
    sync_duration_ms INTEGER,
    synced_at TIMESTAMPTZ DEFAULT NOW(),
    status TEXT DEFAULT 'success',
    error_message TEXT
);

-- ============================================
-- INDEXES
-- ============================================

-- Nodes table indexes
CREATE INDEX IF NOT EXISTS idx_nodes_doc_type 
    ON nodes(doc_type) WHERE is_deleted = FALSE;

CREATE INDEX IF NOT EXISTS idx_nodes_owner 
    ON nodes(owner_id) WHERE is_deleted = FALSE;

CREATE INDEX IF NOT EXISTS idx_nodes_created 
    ON nodes(created) WHERE is_deleted = FALSE;

CREATE INDEX IF NOT EXISTS idx_nodes_last_seen 
    ON nodes(last_seen_txid);

CREATE INDEX IF NOT EXISTS idx_nodes_deleted 
    ON nodes(is_deleted) WHERE is_deleted = TRUE;

CREATE INDEX IF NOT EXISTS idx_nodes_search 
    ON nodes USING GIN(search_vector);

CREATE INDEX IF NOT EXISTS idx_nodes_props 
    ON nodes USING GIN(props);

-- Node children indexes
CREATE INDEX IF NOT EXISTS idx_children_parent 
    ON node_children(parent_id);

CREATE INDEX IF NOT EXISTS idx_children_child 
    ON node_children(child_id);

CREATE INDEX IF NOT EXISTS idx_children_position 
    ON node_children(parent_id, position);

-- Supertags indexes
CREATE INDEX IF NOT EXISTS idx_supertags_base_type 
    ON supertags(base_type);

CREATE INDEX IF NOT EXISTS idx_supertags_name_trgm 
    ON supertags USING GIN(name gin_trgm_ops);

-- Fields indexes
CREATE INDEX IF NOT EXISTS idx_fields_name 
    ON fields(name);

CREATE INDEX IF NOT EXISTS idx_fields_data_type 
    ON fields(data_type);

-- Sync log indexes
CREATE INDEX IF NOT EXISTS idx_sync_log_txid 
    ON sync_log(export_txid);

CREATE INDEX IF NOT EXISTS idx_sync_log_time 
    ON sync_log(synced_at DESC);

-- ============================================
-- VIEWS
-- ============================================

-- Active nodes view (excludes deleted)
CREATE OR REPLACE VIEW active_nodes AS
SELECT * FROM nodes WHERE is_deleted = FALSE;

-- Node hierarchy with depth
CREATE OR REPLACE VIEW node_tree AS
WITH RECURSIVE tree AS (
    SELECT 
        id,
        name,
        doc_type,
        owner_id,
        ARRAY[id] AS path,
        0 AS depth
    FROM nodes
    WHERE owner_id IS NULL AND is_deleted = FALSE
    
    UNION ALL
    
    SELECT 
        n.id,
        n.name,
        n.doc_type,
        n.owner_id,
        t.path || n.id,
        t.depth + 1
    FROM nodes n
    JOIN tree t ON n.owner_id = t.id
    WHERE n.is_deleted = FALSE
      AND t.depth < 10  -- Prevent infinite recursion
)
SELECT * FROM tree;

-- Supertag usage statistics
CREATE OR REPLACE VIEW supertag_stats AS
SELECT 
    s.id,
    s.name,
    s.base_type,
    COUNT(n.id) AS instance_count,
    MAX(n.created) AS last_used,
    MIN(n.created) AS first_used
FROM supertags s
LEFT JOIN nodes n ON n.owner_id = s.id
    AND n.is_deleted = FALSE
GROUP BY s.id, s.name, s.base_type;

-- Recent changes view
CREATE OR REPLACE VIEW recent_changes AS
SELECT 
    id,
    name,
    doc_type,
    created,
    last_synced_at,
    AGE(NOW(), last_synced_at) as age
FROM nodes
WHERE is_deleted = FALSE
ORDER BY last_synced_at DESC
LIMIT 100;

-- ============================================
-- FUNCTIONS
-- ============================================

-- Function to get node with all children
CREATE OR REPLACE FUNCTION get_node_with_children(node_id_param TEXT)
RETURNS TABLE (
    id TEXT,
    name TEXT,
    doc_type TEXT,
    children TEXT[]
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        n.id,
        n.name,
        n.doc_type,
        ARRAY_AGG(nc.child_id ORDER BY nc.position) 
            FILTER (WHERE nc.child_id IS NOT NULL) as children
    FROM nodes n
    LEFT JOIN node_children nc ON n.id = nc.parent_id
    WHERE n.id = node_id_param AND n.is_deleted = FALSE
    GROUP BY n.id, n.name, n.doc_type;
END;
$$ LANGUAGE plpgsql;

-- Function to search nodes by text
CREATE OR REPLACE FUNCTION search_nodes(
    query_text TEXT,
    result_limit INT DEFAULT 20
)
RETURNS TABLE (
    id TEXT,
    name TEXT,
    description TEXT,
    doc_type TEXT,
    rank REAL
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        n.id,
        n.name,
        n.description,
        n.doc_type,
        ts_rank(n.search_vector, to_tsquery('english', query_text)) as rank
    FROM nodes n
    WHERE n.search_vector @@ to_tsquery('english', query_text)
      AND n.is_deleted = FALSE
    ORDER BY rank DESC, n.created DESC
    LIMIT result_limit;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- ARCHIVE TABLE (for full sync backups)
-- ============================================
CREATE TABLE IF NOT EXISTS nodes_archive (
    LIKE nodes INCLUDING ALL,
    archived_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- PERMISSIONS (Optional - for read-only MCP user)
-- ============================================

-- Create read-only user for MCP server (uncomment if needed)
-- CREATE ROLE tanachat_reader WITH LOGIN PASSWORD 'your_secure_password';
-- GRANT CONNECT ON DATABASE tanachat TO tanachat_reader;
-- GRANT USAGE ON SCHEMA public TO tanachat_reader;
-- GRANT SELECT ON ALL TABLES IN SCHEMA public TO tanachat_reader;
-- GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO tanachat_reader;
-- ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO tanachat_reader;

-- ============================================
-- INITIAL DATA VALIDATION
-- ============================================

-- Verify schema is ready
DO $$
BEGIN
    RAISE NOTICE 'TanaChat schema installed successfully';
    RAISE NOTICE 'Tables: nodes, node_children, supertags, fields, sync_log';
    RAISE NOTICE 'Views: active_nodes, node_tree, supertag_stats, recent_changes';
    RAISE NOTICE 'Functions: get_node_with_children, search_nodes';
END $$;
