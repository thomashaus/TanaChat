# TanaChat Upgrade Specification
## PostgreSQL Sync + MCP Server Integration

**Project:** TanaChat v2.0
**Author:** Tom Haus
**Date:** December 2024
**Repository:** https://github.com/thomashaus/TanaChat

---

## Executive Summary

Upgrade TanaChat from a simple Tana JSON reader to a robust PostgreSQL-backed MCP server that enables:
- Daily incremental sync from Tana exports
- Fast SQL queries on nodes, supertags, and relationships
- MCP tools for AI-assisted knowledge management
- Change tracking and historical data preservation

---

## Current State Assessment

### Assumptions about TanaChat v1.x:
- Reads Tana JSON exports directly
- Limited query capabilities
- No persistence between runs
- Manual export/load process

### Limitations to Address:
1. No incremental updates (full reload each time)
2. No relationship indexing (slow hierarchy traversal)
3. No change history
4. No multi-user/multi-workspace support
5. Limited query patterns

---

## Architecture Overview

```
┌─────────────────┐
│   Tana.inc      │
│  (Manual Export)│
└────────┬────────┘
         │ JSON
         ▼
┌─────────────────────────────────────────┐
│         Sync Engine (Python)            │
│  - Change detection (hash + txid)       │
│  - UPSERT logic                         │
│  - Relationship mapping                 │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│      PostgreSQL Database                │
│  - nodes (core table)                   │
│  - node_children (hierarchy)            │
│  - supertags (denormalized)             │
│  - fields (field definitions)           │
│  - sync_log (audit trail)               │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│      FastMCP Server (Python)            │
│  - query_nodes                          │
│  - search_by_supertag                   │
│  - get_node_hierarchy                   │
│  - find_related_nodes                   │
│  - get_sync_status                      │
└─────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│    Claude Desktop / API Clients         │
└─────────────────────────────────────────┘
```

---

## Database Schema

### Core Tables

```sql
-- ============================================
-- NODES TABLE: Core entity storage
-- ============================================
CREATE TABLE nodes (
    -- Identity
    id TEXT PRIMARY KEY,
    
    -- Core properties
    doc_type TEXT,                      -- tagDef, tuple, metanode, search, etc.
    name TEXT,
    description TEXT,
    
    -- Relationships
    owner_id TEXT REFERENCES nodes(id),
    meta_node_id TEXT REFERENCES nodes(id),
    source_id TEXT REFERENCES nodes(id),
    
    -- Timestamps
    created BIGINT,                     -- Unix timestamp in milliseconds
    
    -- Flexible storage for Tana-specific props
    props JSONB,                        -- All other properties as JSON
    modified_ts JSONB,                  -- Per-editor modification timestamps
    touch_counts JSONB,                 -- Per-editor touch counts
    
    -- Sync tracking
    last_seen_txid BIGINT NOT NULL,     -- Last transaction where this node was seen
    last_synced_at TIMESTAMPTZ DEFAULT NOW(),
    is_deleted BOOLEAN DEFAULT FALSE,
    sync_hash TEXT NOT NULL,            -- SHA256 of node content for change detection
    
    -- Full-text search
    search_vector TSVECTOR GENERATED ALWAYS AS (
        to_tsvector('english', COALESCE(name, '') || ' ' || COALESCE(description, ''))
    ) STORED
);

-- ============================================
-- NODE_CHILDREN: Hierarchical relationships
-- ============================================
CREATE TABLE node_children (
    parent_id TEXT NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
    child_id TEXT NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
    position INTEGER NOT NULL,          -- Preserve order from Tana
    
    PRIMARY KEY (parent_id, child_id)
);

-- ============================================
-- SUPERTAGS: Denormalized for fast lookups
-- ============================================
CREATE TABLE supertags (
    id TEXT PRIMARY KEY REFERENCES nodes(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    base_type TEXT,                     -- person, task, project, meeting, etc.
    
    -- Field definitions for this supertag
    field_ids TEXT[],                   -- Array of field definition IDs
    
    props JSONB,
    
    -- Full-text search
    CONSTRAINT supertags_name_unique UNIQUE (name)
);

-- ============================================
-- FIELDS: Field definitions (columns/attributes)
-- ============================================
CREATE TABLE fields (
    id TEXT PRIMARY KEY REFERENCES nodes(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    
    -- Type information
    data_type TEXT,                     -- References to SYS_D* nodes
    value_constraint TEXT,              -- single, list, etc.
    
    -- Options for select fields
    options TEXT[],                     -- Array of option node IDs
    
    props JSONB
);

-- ============================================
-- SYNC_LOG: Audit trail for all sync operations
-- ============================================
CREATE TABLE sync_log (
    sync_id SERIAL PRIMARY KEY,
    export_txid BIGINT NOT NULL,
    export_filename TEXT,
    
    -- Metrics
    nodes_added INTEGER DEFAULT 0,
    nodes_updated INTEGER DEFAULT 0,
    nodes_deleted INTEGER DEFAULT 0,
    nodes_unchanged INTEGER DEFAULT 0,
    
    -- Performance
    sync_duration_ms INTEGER,
    
    -- Timestamps
    synced_at TIMESTAMPTZ DEFAULT NOW(),
    
    -- Status
    status TEXT DEFAULT 'success',      -- success, partial, failed
    error_message TEXT
);

-- ============================================
-- INDEXES for query performance
-- ============================================

-- Core lookups
CREATE INDEX idx_nodes_doc_type ON nodes(doc_type) WHERE is_deleted = FALSE;
CREATE INDEX idx_nodes_owner ON nodes(owner_id) WHERE is_deleted = FALSE;
CREATE INDEX idx_nodes_created ON nodes(created) WHERE is_deleted = FALSE;

-- Sync tracking
CREATE INDEX idx_nodes_last_seen ON nodes(last_seen_txid);
CREATE INDEX idx_nodes_deleted ON nodes(is_deleted) WHERE is_deleted = TRUE;

-- Full-text search
CREATE INDEX idx_nodes_search ON nodes USING GIN(search_vector);
CREATE INDEX idx_nodes_props ON nodes USING GIN(props);

-- Hierarchical queries
CREATE INDEX idx_children_parent ON node_children(parent_id);
CREATE INDEX idx_children_child ON node_children(child_id);
CREATE INDEX idx_children_position ON node_children(parent_id, position);

-- Supertag lookups
CREATE INDEX idx_supertags_base_type ON supertags(base_type);
CREATE INDEX idx_supertags_name_trgm ON supertags USING GIN(name gin_trgm_ops);

-- Field lookups
CREATE INDEX idx_fields_name ON fields(name);
CREATE INDEX idx_fields_data_type ON fields(data_type);
```

### Database Views (Optional but Recommended)

```sql
-- ============================================
-- VIEW: Active nodes (not deleted)
-- ============================================
CREATE VIEW active_nodes AS
SELECT * FROM nodes WHERE is_deleted = FALSE;

-- ============================================
-- VIEW: Node hierarchy with depth
-- ============================================
CREATE VIEW node_tree AS
WITH RECURSIVE tree AS (
    SELECT 
        id,
        name,
        owner_id,
        ARRAY[id] AS path,
        0 AS depth
    FROM nodes
    WHERE owner_id IS NULL AND is_deleted = FALSE
    
    UNION ALL
    
    SELECT 
        n.id,
        n.name,
        n.owner_id,
        t.path || n.id,
        t.depth + 1
    FROM nodes n
    JOIN tree t ON n.owner_id = t.id
    WHERE n.is_deleted = FALSE
)
SELECT * FROM tree;

-- ============================================
-- VIEW: Supertag usage statistics
-- ============================================
CREATE VIEW supertag_stats AS
SELECT 
    s.id,
    s.name,
    s.base_type,
    COUNT(n.id) AS instance_count,
    MAX(n.created) AS last_used
FROM supertags s
LEFT JOIN nodes n ON n.props->>'_docType' = 'tuple' 
                  AND n.owner_id = s.id
                  AND n.is_deleted = FALSE
GROUP BY s.id, s.name, s.base_type;
```

---

## Sync Engine Implementation

### File Structure

```
tanachat/
├── sync_engine/
│   ├── __init__.py
│   ├── sync.py              # Main sync orchestration
│   ├── parser.py            # Tana JSON parser
│   ├── hasher.py            # Content hashing utilities
│   ├── db.py                # Database operations
│   └── models.py            # Data models
├── mcp_server/
│   ├── __init__.py
│   ├── server.py            # FastMCP server
│   ├── tools.py             # MCP tool implementations
│   └── queries.py           # SQL query builders
├── cli/
│   ├── __init__.py
│   └── main.py              # CLI interface
├── config/
│   └── config.yaml          # Configuration
├── tests/
│   ├── test_sync.py
│   ├── test_mcp.py
│   └── fixtures/
├── requirements.txt
└── README.md
```

### Core Sync Engine (sync_engine/sync.py)

```python
"""
TanaChat Sync Engine
Handles incremental synchronization from Tana exports to PostgreSQL
"""

import json
import hashlib
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Set, Tuple

import psycopg2
from psycopg2.extras import execute_values

from .parser import TanaParser
from .db import DatabaseManager
from .hasher import calculate_node_hash

logger = logging.getLogger(__name__)


class SyncEngine:
    """Main sync engine for Tana -> PostgreSQL"""
    
    def __init__(self, db_connection_string: str):
        self.db = DatabaseManager(db_connection_string)
        self.parser = TanaParser()
        
    def sync_export(
        self, 
        export_path: Path, 
        mode: str = 'incremental'
    ) -> Dict[str, int]:
        """
        Sync a Tana export to PostgreSQL
        
        Args:
            export_path: Path to Tana JSON export
            mode: 'incremental' or 'full' (full = replace all)
            
        Returns:
            Dict with sync statistics
        """
        logger.info(f"Starting sync: {export_path} (mode={mode})")
        sync_start = datetime.now()
        
        # Parse export
        export_data = self.parser.parse_export(export_path)
        export_txid = export_data['lastTxid']
        
        # Get last sync info
        last_sync = self.db.get_last_sync()
        last_txid = last_sync['export_txid'] if last_sync else 0
        
        logger.info(f"Export txid: {export_txid}, Last synced: {last_txid}")
        
        # Check if this export is new
        if export_txid <= last_txid:
            logger.warning(f"Export not newer than last sync. Skipping.")
            return {'status': 'skipped', 'reason': 'not_newer'}
        
        # Execute sync based on mode
        if mode == 'full':
            stats = self._full_sync(export_data, export_txid)
        else:
            stats = self._incremental_sync(export_data, export_txid)
        
        # Calculate duration
        duration_ms = int((datetime.now() - sync_start).total_seconds() * 1000)
        
        # Log sync
        self.db.log_sync(
            export_txid=export_txid,
            export_filename=str(export_path),
            stats=stats,
            duration_ms=duration_ms
        )
        
        logger.info(f"Sync complete: {stats}")
        return stats
    
    def _incremental_sync(
        self, 
        export_data: Dict, 
        export_txid: int
    ) -> Dict[str, int]:
        """Incremental sync with change detection"""
        
        stats = {
            'nodes_added': 0,
            'nodes_updated': 0,
            'nodes_deleted': 0,
            'nodes_unchanged': 0
        }
        
        current_node_ids = set()
        nodes_to_insert = []
        nodes_to_update = []
        
        # Process each document
        for doc in export_data['docs']:
            node_id = doc['id']
            current_node_ids.add(node_id)
            
            # Calculate content hash
            content_hash = calculate_node_hash(doc)
            
            # Check if node exists
            existing = self.db.get_node_hash(node_id)
            
            if not existing:
                # New node
                nodes_to_insert.append((doc, content_hash))
                stats['nodes_added'] += 1
                
            elif existing['sync_hash'] != content_hash:
                # Changed node
                nodes_to_update.append((doc, content_hash))
                stats['nodes_updated'] += 1
                
            else:
                # Unchanged - just update last_seen_txid
                self.db.touch_node(node_id, export_txid)
                stats['nodes_unchanged'] += 1
        
        # Batch insert new nodes
        if nodes_to_insert:
            self.db.batch_insert_nodes(nodes_to_insert, export_txid)
        
        # Batch update changed nodes
        if nodes_to_update:
            self.db.batch_update_nodes(nodes_to_update, export_txid)
        
        # Mark deleted nodes
        stats['nodes_deleted'] = self.db.mark_deleted_nodes(
            export_txid, 
            current_node_ids
        )
        
        # Update denormalized tables
        self._update_supertags()
        self._update_fields()
        
        return stats
    
    def _full_sync(self, export_data: Dict, export_txid: int) -> Dict[str, int]:
        """Full sync - replace everything"""
        
        logger.info("Performing full sync (replace all)")
        
        # Archive current data
        self.db.archive_current_data()
        
        # Truncate tables
        self.db.truncate_all()
        
        # Insert all nodes
        nodes_with_hash = [
            (doc, calculate_node_hash(doc)) 
            for doc in export_data['docs']
        ]
        
        self.db.batch_insert_nodes(nodes_with_hash, export_txid)
        
        # Update denormalized tables
        self._update_supertags()
        self._update_fields()
        
        return {
            'nodes_added': len(nodes_with_hash),
            'nodes_updated': 0,
            'nodes_deleted': 0,
            'nodes_unchanged': 0
        }
    
    def _update_supertags(self):
        """Update denormalized supertags table"""
        self.db.rebuild_supertags()
    
    def _update_fields(self):
        """Update denormalized fields table"""
        self.db.rebuild_fields()
```

### Database Manager (sync_engine/db.py)

```python
"""
Database operations for TanaChat sync
"""

import logging
from typing import Dict, List, Optional, Set, Tuple
import json

import psycopg2
from psycopg2.extras import execute_values, Json

logger = logging.getLogger(__name__)


class DatabaseManager:
    """PostgreSQL database operations"""
    
    def __init__(self, connection_string: str):
        self.conn_string = connection_string
        self.conn = None
        self._connect()
    
    def _connect(self):
        """Establish database connection"""
        self.conn = psycopg2.connect(self.conn_string)
        self.conn.autocommit = False
    
    def get_last_sync(self) -> Optional[Dict]:
        """Get most recent sync log entry"""
        with self.conn.cursor() as cur:
            cur.execute("""
                SELECT export_txid, synced_at, status
                FROM sync_log
                WHERE status = 'success'
                ORDER BY synced_at DESC
                LIMIT 1
            """)
            row = cur.fetchone()
            if row:
                return {
                    'export_txid': row[0],
                    'synced_at': row[1],
                    'status': row[2]
                }
        return None
    
    def get_node_hash(self, node_id: str) -> Optional[Dict]:
        """Get sync hash for a node"""
        with self.conn.cursor() as cur:
            cur.execute(
                "SELECT sync_hash FROM nodes WHERE id = %s",
                (node_id,)
            )
            row = cur.fetchone()
            if row:
                return {'sync_hash': row[0]}
        return None
    
    def touch_node(self, node_id: str, txid: int):
        """Update last_seen_txid for unchanged node"""
        with self.conn.cursor() as cur:
            cur.execute(
                "UPDATE nodes SET last_seen_txid = %s WHERE id = %s",
                (txid, node_id)
            )
    
    def batch_insert_nodes(
        self, 
        nodes_with_hash: List[Tuple[Dict, str]], 
        txid: int
    ):
        """Bulk insert new nodes"""
        logger.info(f"Inserting {len(nodes_with_hash)} nodes")
        
        # Prepare node data
        node_values = []
        children_values = []
        
        for doc, content_hash in nodes_with_hash:
            props = doc.get('props', {})
            
            node_values.append((
                doc['id'],
                props.get('_docType'),
                props.get('name'),
                props.get('description'),
                props.get('_ownerId'),
                props.get('_metaNodeId'),
                props.get('_sourceId'),
                props.get('created'),
                Json(props),
                Json(doc.get('modifiedTs', {})),
                Json(doc.get('touchCounts', {})),
                txid,
                content_hash
            ))
            
            # Prepare children relationships
            if 'children' in doc:
                for position, child_id in enumerate(doc['children']):
                    children_values.append((
                        doc['id'],
                        child_id,
                        position
                    ))
        
        # Batch insert nodes
        with self.conn.cursor() as cur:
            execute_values(
                cur,
                """
                INSERT INTO nodes (
                    id, doc_type, name, description, owner_id,
                    meta_node_id, source_id, created, props,
                    modified_ts, touch_counts, last_seen_txid, sync_hash
                ) VALUES %s
                """,
                node_values
            )
            
            # Batch insert children
            if children_values:
                execute_values(
                    cur,
                    """
                    INSERT INTO node_children (parent_id, child_id, position)
                    VALUES %s
                    ON CONFLICT (parent_id, child_id) 
                    DO UPDATE SET position = EXCLUDED.position
                    """,
                    children_values
                )
        
        self.conn.commit()
    
    def batch_update_nodes(
        self, 
        nodes_with_hash: List[Tuple[Dict, str]], 
        txid: int
    ):
        """Bulk update changed nodes"""
        logger.info(f"Updating {len(nodes_with_hash)} nodes")
        
        with self.conn.cursor() as cur:
            for doc, content_hash in nodes_with_hash:
                props = doc.get('props', {})
                
                # Update node
                cur.execute("""
                    UPDATE nodes SET
                        doc_type = %s,
                        name = %s,
                        description = %s,
                        owner_id = %s,
                        meta_node_id = %s,
                        source_id = %s,
                        props = %s,
                        modified_ts = %s,
                        touch_counts = %s,
                        last_seen_txid = %s,
                        sync_hash = %s,
                        last_synced_at = NOW()
                    WHERE id = %s
                """, (
                    props.get('_docType'),
                    props.get('name'),
                    props.get('description'),
                    props.get('_ownerId'),
                    props.get('_metaNodeId'),
                    props.get('_sourceId'),
                    Json(props),
                    Json(doc.get('modifiedTs', {})),
                    Json(doc.get('touchCounts', {})),
                    txid,
                    content_hash,
                    doc['id']
                ))
                
                # Update children
                cur.execute(
                    "DELETE FROM node_children WHERE parent_id = %s",
                    (doc['id'],)
                )
                
                if 'children' in doc:
                    children_values = [
                        (doc['id'], child_id, pos)
                        for pos, child_id in enumerate(doc['children'])
                    ]
                    execute_values(
                        cur,
                        """
                        INSERT INTO node_children (parent_id, child_id, position)
                        VALUES %s
                        """,
                        children_values
                    )
        
        self.conn.commit()
    
    def mark_deleted_nodes(self, txid: int, current_ids: Set[str]) -> int:
        """Mark nodes not in export as deleted"""
        with self.conn.cursor() as cur:
            cur.execute("""
                UPDATE nodes
                SET is_deleted = TRUE
                WHERE last_seen_txid < %s
                  AND is_deleted = FALSE
                  AND id NOT IN %s
            """, (txid, tuple(current_ids)))
            
            deleted_count = cur.rowcount
        
        self.conn.commit()
        return deleted_count
    
    def rebuild_supertags(self):
        """Rebuild denormalized supertags table"""
        with self.conn.cursor() as cur:
            cur.execute("""
                INSERT INTO supertags (id, name, description, base_type, props)
                SELECT 
                    id,
                    name,
                    description,
                    CASE 
                        WHEN name LIKE '%(base type)' 
                        THEN TRIM(REPLACE(name, '(base type)', ''))
                        ELSE NULL
                    END as base_type,
                    props
                FROM nodes
                WHERE doc_type = 'tagDef'
                  AND is_deleted = FALSE
                ON CONFLICT (id) DO UPDATE SET
                    name = EXCLUDED.name,
                    description = EXCLUDED.description,
                    base_type = EXCLUDED.base_type,
                    props = EXCLUDED.props
            """)
        
        self.conn.commit()
    
    def rebuild_fields(self):
        """Rebuild denormalized fields table"""
        with self.conn.cursor() as cur:
            cur.execute("""
                INSERT INTO fields (id, name, description, props)
                SELECT 
                    id,
                    name,
                    description,
                    props
                FROM nodes
                WHERE owner_id IN (
                    SELECT id FROM nodes WHERE doc_type = 'tagDef'
                )
                  AND is_deleted = FALSE
                ON CONFLICT (id) DO UPDATE SET
                    name = EXCLUDED.name,
                    description = EXCLUDED.description,
                    props = EXCLUDED.props
            """)
        
        self.conn.commit()
    
    def log_sync(
        self, 
        export_txid: int, 
        export_filename: str,
        stats: Dict[str, int],
        duration_ms: int
    ):
        """Log sync operation"""
        with self.conn.cursor() as cur:
            cur.execute("""
                INSERT INTO sync_log (
                    export_txid, export_filename,
                    nodes_added, nodes_updated, nodes_deleted, nodes_unchanged,
                    sync_duration_ms, status
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                export_txid,
                export_filename,
                stats.get('nodes_added', 0),
                stats.get('nodes_updated', 0),
                stats.get('nodes_deleted', 0),
                stats.get('nodes_unchanged', 0),
                duration_ms,
                'success'
            ))
        
        self.conn.commit()
    
    def archive_current_data(self):
        """Archive current data before full sync"""
        with self.conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS nodes_archive (
                    LIKE nodes INCLUDING ALL,
                    archived_at TIMESTAMPTZ DEFAULT NOW()
                )
            """)
            cur.execute("""
                INSERT INTO nodes_archive 
                SELECT *, NOW() FROM nodes
            """)
        
        self.conn.commit()
    
    def truncate_all(self):
        """Truncate all sync tables"""
        with self.conn.cursor() as cur:
            cur.execute("TRUNCATE nodes CASCADE")
            cur.execute("TRUNCATE node_children CASCADE")
            cur.execute("TRUNCATE supertags CASCADE")
            cur.execute("TRUNCATE fields CASCADE")
        
        self.conn.commit()
```

### Content Hasher (sync_engine/hasher.py)

```python
"""
Content hashing for change detection
"""

import hashlib
import json
from typing import Dict


def calculate_node_hash(doc: Dict) -> str:
    """
    Calculate SHA256 hash of node content
    
    Excludes modifiedTs and touchCounts from hash since
    those change frequently but don't represent content changes
    """
    # Create normalized copy
    normalized = {
        'id': doc['id'],
        'props': doc.get('props', {}),
        'children': doc.get('children', [])
    }
    
    # Remove metadata that changes frequently
    if 'props' in normalized:
        props_copy = normalized['props'].copy()
        # Keep modifiedTs out of hash - it changes on every view
        props_copy.pop('modifiedTs', None)
        props_copy.pop('touchCounts', None)
        normalized['props'] = props_copy
    
    # Calculate hash
    content_json = json.dumps(normalized, sort_keys=True)
    return hashlib.sha256(content_json.encode()).hexdigest()
```

### Tana Parser (sync_engine/parser.py)

```python
"""
Tana export parser
"""

import json
import logging
from pathlib import Path
from typing import Dict

logger = logging.getLogger(__name__)


class TanaParser:
    """Parse Tana JSON exports"""
    
    def parse_export(self, export_path: Path) -> Dict:
        """
        Parse a Tana export file
        
        Returns:
            Dict with 'docs', 'lastTxid', etc.
        """
        logger.info(f"Parsing export: {export_path}")
        
        with open(export_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Validate structure
        self._validate_export(data)
        
        logger.info(f"Parsed {len(data['docs'])} documents")
        return data
    
    def _validate_export(self, data: Dict):
        """Validate export structure"""
        required_keys = ['docs', 'lastTxid', 'formatVersion']
        
        for key in required_keys:
            if key not in data:
                raise ValueError(f"Invalid export: missing '{key}'")
        
        if data['formatVersion'] != 1:
            logger.warning(
                f"Unknown format version: {data['formatVersion']}"
            )
```

---

## MCP Server Implementation

### FastMCP Server (mcp_server/server.py)

```python
"""
TanaChat MCP Server
Exposes Tana data via Model Context Protocol
"""

import logging
from typing import List, Dict, Optional

from mcp import FastMCP

from .queries import TanaQueries

logger = logging.getLogger(__name__)

# Initialize MCP server
mcp = FastMCP("TanaChat")

# Initialize query engine
db_connection_string = "postgresql://localhost/tanachat"
queries = TanaQueries(db_connection_string)


@mcp.tool()
def query_nodes(
    query: str = None,
    doc_type: str = None,
    limit: int = 20,
    offset: int = 0
) -> List[Dict]:
    """
    Query Tana nodes with optional filters
    
    Args:
        query: Full-text search query (searches name and description)
        doc_type: Filter by document type (tagDef, tuple, metanode, etc.)
        limit: Maximum number of results (default: 20)
        offset: Offset for pagination (default: 0)
    
    Returns:
        List of matching nodes with their properties
    """
    return queries.query_nodes(query, doc_type, limit, offset)


@mcp.tool()
def get_node_by_id(node_id: str) -> Optional[Dict]:
    """
    Get a specific node by its ID
    
    Args:
        node_id: The node ID to retrieve
    
    Returns:
        Node data with relationships, or None if not found
    """
    return queries.get_node_by_id(node_id)


@mcp.tool()
def search_by_supertag(
    supertag_name: str,
    limit: int = 50
) -> List[Dict]:
    """
    Find all nodes tagged with a specific supertag
    
    Args:
        supertag_name: Name of the supertag (e.g., "task", "person", "project")
        limit: Maximum number of results
    
    Returns:
        List of nodes with that supertag
    """
    return queries.search_by_supertag(supertag_name, limit)


@mcp.tool()
def get_node_hierarchy(
    node_id: str,
    max_depth: int = 3
) -> Dict:
    """
    Get a node and its descendants in a tree structure
    
    Args:
        node_id: Root node ID
        max_depth: Maximum depth to traverse (default: 3)
    
    Returns:
        Hierarchical structure with nested children
    """
    return queries.get_node_hierarchy(node_id, max_depth)


@mcp.tool()
def find_related_nodes(
    node_id: str,
    relationship_type: str = 'all'
) -> Dict:
    """
    Find nodes related to the given node
    
    Args:
        node_id: The node to find relationships for
        relationship_type: Type of relationship ('parent', 'children', 'siblings', 'all')
    
    Returns:
        Dict with related nodes organized by relationship type
    """
    return queries.find_related_nodes(node_id, relationship_type)


@mcp.tool()
def get_supertags(
    base_type: str = None
) -> List[Dict]:
    """
    List all available supertags
    
    Args:
        base_type: Filter by base type (person, task, project, etc.)
    
    Returns:
        List of supertag definitions with usage statistics
    """
    return queries.get_supertags(base_type)


@mcp.tool()
def search_full_text(
    query: str,
    limit: int = 30
) -> List[Dict]:
    """
    Full-text search across all nodes using PostgreSQL's tsvector
    
    Args:
        query: Search query (supports Boolean operators: AND, OR, NOT)
        limit: Maximum number of results
    
    Returns:
        Ranked list of matching nodes with relevance scores
    """
    return queries.search_full_text(query, limit)


@mcp.tool()
def get_sync_status() -> Dict:
    """
    Get the status of the last Tana sync operation
    
    Returns:
        Dict with sync metrics, timestamp, and statistics
    """
    return queries.get_sync_status()


@mcp.tool()
def get_recent_changes(
    hours: int = 24,
    limit: int = 50
) -> List[Dict]:
    """
    Get nodes that were recently created or modified
    
    Args:
        hours: Look back this many hours (default: 24)
        limit: Maximum number of results
    
    Returns:
        List of recently changed nodes
    """
    return queries.get_recent_changes(hours, limit)


@mcp.tool()
def query_by_field(
    field_name: str,
    field_value: str = None,
    supertag_name: str = None
) -> List[Dict]:
    """
    Query nodes by a specific field value
    
    Args:
        field_name: Name of the field to query
        field_value: Value to search for (optional - if None, returns all nodes with this field)
        supertag_name: Limit to nodes with specific supertag (optional)
    
    Returns:
        List of nodes matching the field criteria
    """
    return queries.query_by_field(field_name, field_value, supertag_name)


if __name__ == "__main__":
    # Run the MCP server
    mcp.run()
```

### Query Engine (mcp_server/queries.py)

```python
"""
SQL query builder for TanaChat MCP tools
"""

import logging
from typing import List, Dict, Optional
from datetime import datetime, timedelta

import psycopg2
from psycopg2.extras import RealDictCursor

logger = logging.getLogger(__name__)


class TanaQueries:
    """SQL queries for Tana data"""
    
    def __init__(self, connection_string: str):
        self.conn = psycopg2.connect(connection_string)
    
    def query_nodes(
        self,
        query: Optional[str] = None,
        doc_type: Optional[str] = None,
        limit: int = 20,
        offset: int = 0
    ) -> List[Dict]:
        """Query nodes with filters"""
        
        sql = """
            SELECT 
                id, doc_type, name, description, owner_id,
                created, props
            FROM nodes
            WHERE is_deleted = FALSE
        """
        params = []
        
        if doc_type:
            sql += " AND doc_type = %s"
            params.append(doc_type)
        
        if query:
            sql += " AND (name ILIKE %s OR description ILIKE %s)"
            params.extend([f'%{query}%', f'%{query}%'])
        
        sql += " ORDER BY created DESC LIMIT %s OFFSET %s"
        params.extend([limit, offset])
        
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(sql, params)
            return [dict(row) for row in cur.fetchall()]
    
    def get_node_by_id(self, node_id: str) -> Optional[Dict]:
        """Get a specific node with relationships"""
        
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            # Get node
            cur.execute("""
                SELECT 
                    n.*,
                    ARRAY_AGG(nc.child_id ORDER BY nc.position) 
                        FILTER (WHERE nc.child_id IS NOT NULL) as children
                FROM nodes n
                LEFT JOIN node_children nc ON n.id = nc.parent_id
                WHERE n.id = %s AND n.is_deleted = FALSE
                GROUP BY n.id
            """, (node_id,))
            
            row = cur.fetchone()
            return dict(row) if row else None
    
    def search_by_supertag(
        self, 
        supertag_name: str, 
        limit: int = 50
    ) -> List[Dict]:
        """Find nodes with a specific supertag"""
        
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT n.*
                FROM nodes n
                JOIN supertags s ON n.owner_id = s.id
                WHERE s.name ILIKE %s
                  AND n.is_deleted = FALSE
                ORDER BY n.created DESC
                LIMIT %s
            """, (f'%{supertag_name}%', limit))
            
            return [dict(row) for row in cur.fetchall()]
    
    def get_node_hierarchy(
        self, 
        node_id: str, 
        max_depth: int = 3
    ) -> Dict:
        """Get hierarchical tree of node and descendants"""
        
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                WITH RECURSIVE tree AS (
                    -- Base case
                    SELECT 
                        id, name, doc_type, owner_id,
                        ARRAY[id] as path,
                        0 as depth
                    FROM nodes
                    WHERE id = %s AND is_deleted = FALSE
                    
                    UNION ALL
                    
                    -- Recursive case
                    SELECT 
                        n.id, n.name, n.doc_type, n.owner_id,
                        t.path || n.id,
                        t.depth + 1
                    FROM nodes n
                    JOIN node_children nc ON n.id = nc.child_id
                    JOIN tree t ON nc.parent_id = t.id
                    WHERE n.is_deleted = FALSE
                      AND t.depth < %s
                )
                SELECT * FROM tree
                ORDER BY path
            """, (node_id, max_depth))
            
            rows = [dict(row) for row in cur.fetchall()]
            
            # Convert to hierarchical structure
            return self._build_tree(rows)
    
    def _build_tree(self, rows: List[Dict]) -> Dict:
        """Convert flat list to nested tree"""
        if not rows:
            return {}
        
        # Create node lookup
        nodes = {row['id']: row for row in rows}
        
        # Build tree
        root = None
        for row in rows:
            row['children'] = []
            if row['depth'] == 0:
                root = row
            else:
                parent_id = row['path'][-2]
                if parent_id in nodes:
                    nodes[parent_id]['children'].append(row)
        
        return root or {}
    
    def find_related_nodes(
        self, 
        node_id: str, 
        relationship_type: str = 'all'
    ) -> Dict:
        """Find related nodes"""
        
        result = {}
        
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            if relationship_type in ('parent', 'all'):
                cur.execute("""
                    SELECT n.*
                    FROM nodes n
                    WHERE id = (
                        SELECT owner_id FROM nodes WHERE id = %s
                    )
                    AND is_deleted = FALSE
                """, (node_id,))
                result['parent'] = dict(cur.fetchone()) if cur.rowcount > 0 else None
            
            if relationship_type in ('children', 'all'):
                cur.execute("""
                    SELECT n.*
                    FROM nodes n
                    JOIN node_children nc ON n.id = nc.child_id
                    WHERE nc.parent_id = %s
                      AND n.is_deleted = FALSE
                    ORDER BY nc.position
                """, (node_id,))
                result['children'] = [dict(row) for row in cur.fetchall()]
            
            if relationship_type in ('siblings', 'all'):
                cur.execute("""
                    SELECT n.*
                    FROM nodes n
                    WHERE n.owner_id = (
                        SELECT owner_id FROM nodes WHERE id = %s
                    )
                    AND n.id != %s
                    AND n.is_deleted = FALSE
                    ORDER BY n.created
                """, (node_id, node_id))
                result['siblings'] = [dict(row) for row in cur.fetchall()]
        
        return result
    
    def get_supertags(self, base_type: Optional[str] = None) -> List[Dict]:
        """Get all supertags with usage stats"""
        
        sql = """
            SELECT 
                s.*,
                COUNT(n.id) as usage_count
            FROM supertags s
            LEFT JOIN nodes n ON n.owner_id = s.id 
                AND n.is_deleted = FALSE
        """
        
        params = []
        if base_type:
            sql += " WHERE s.base_type = %s"
            params.append(base_type)
        
        sql += " GROUP BY s.id ORDER BY s.name"
        
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(sql, params)
            return [dict(row) for row in cur.fetchall()]
    
    def search_full_text(self, query: str, limit: int = 30) -> List[Dict]:
        """Full-text search with ranking"""
        
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT 
                    id, doc_type, name, description,
                    ts_rank(search_vector, to_tsquery('english', %s)) as rank
                FROM nodes
                WHERE search_vector @@ to_tsquery('english', %s)
                  AND is_deleted = FALSE
                ORDER BY rank DESC, created DESC
                LIMIT %s
            """, (query, query, limit))
            
            return [dict(row) for row in cur.fetchall()]
    
    def get_sync_status(self) -> Dict:
        """Get last sync status"""
        
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT *
                FROM sync_log
                ORDER BY synced_at DESC
                LIMIT 1
            """)
            
            row = cur.fetchone()
            if row:
                return dict(row)
            
            return {'status': 'no_sync_yet'}
    
    def get_recent_changes(self, hours: int = 24, limit: int = 50) -> List[Dict]:
        """Get recently changed nodes"""
        
        cutoff = datetime.now() - timedelta(hours=hours)
        cutoff_ms = int(cutoff.timestamp() * 1000)
        
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT *
                FROM nodes
                WHERE created > %s
                  AND is_deleted = FALSE
                ORDER BY created DESC
                LIMIT %s
            """, (cutoff_ms, limit))
            
            return [dict(row) for row in cur.fetchall()]
    
    def query_by_field(
        self,
        field_name: str,
        field_value: Optional[str] = None,
        supertag_name: Optional[str] = None
    ) -> List[Dict]:
        """Query nodes by field values stored in props JSONB"""
        
        sql = """
            SELECT n.*
            FROM nodes n
            WHERE n.is_deleted = FALSE
              AND n.props ? %s
        """
        params = [field_name]
        
        if field_value:
            sql += " AND n.props->>%s ILIKE %s"
            params.extend([field_name, f'%{field_value}%'])
        
        if supertag_name:
            sql += """
                AND n.owner_id IN (
                    SELECT id FROM supertags WHERE name ILIKE %s
                )
            """
            params.append(f'%{supertag_name}%')
        
        sql += " ORDER BY n.created DESC LIMIT 100"
        
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(sql, params)
            return [dict(row) for row in cur.fetchall()]
```

---

## CLI Implementation

### Main CLI (cli/main.py)

```python
"""
TanaChat CLI
Command-line interface for sync and management
"""

import click
import logging
from pathlib import Path
from typing import Optional

from sync_engine.sync import SyncEngine
from mcp_server.queries import TanaQueries


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@click.group()
def cli():
    """TanaChat - Tana export sync and MCP server"""
    pass


@cli.command()
@click.argument('export_path', type=click.Path(exists=True))
@click.option('--db', 'db_string', 
              default='postgresql://localhost/tanachat',
              help='PostgreSQL connection string')
@click.option('--mode', type=click.Choice(['incremental', 'full']),
              default='incremental',
              help='Sync mode (incremental or full)')
def sync(export_path: str, db_string: str, mode: str):
    """Sync a Tana export to PostgreSQL"""
    
    engine = SyncEngine(db_string)
    
    try:
        stats = engine.sync_export(Path(export_path), mode)
        
        click.echo(click.style("✓ Sync completed successfully", fg='green'))
        click.echo(f"  Added:     {stats['nodes_added']}")
        click.echo(f"  Updated:   {stats['nodes_updated']}")
        click.echo(f"  Deleted:   {stats['nodes_deleted']}")
        click.echo(f"  Unchanged: {stats['nodes_unchanged']}")
        
    except Exception as e:
        logger.exception("Sync failed")
        click.echo(click.style(f"✗ Sync failed: {e}", fg='red'))
        raise click.Abort()


@cli.command()
@click.option('--db', 'db_string',
              default='postgresql://localhost/tanachat',
              help='PostgreSQL connection string')
def status(db_string: str):
    """Show sync status"""
    
    queries = TanaQueries(db_string)
    status_info = queries.get_sync_status()
    
    if status_info.get('status') == 'no_sync_yet':
        click.echo(click.style("No syncs performed yet", fg='yellow'))
        return
    
    click.echo(click.style("Last Sync Status:", fg='blue', bold=True))
    click.echo(f"  Transaction ID: {status_info['export_txid']}")
    click.echo(f"  Synced at:      {status_info['synced_at']}")
    click.echo(f"  Duration:       {status_info['sync_duration_ms']}ms")
    click.echo(f"  Status:         {status_info['status']}")
    click.echo()
    click.echo(f"  Nodes added:    {status_info['nodes_added']}")
    click.echo(f"  Nodes updated:  {status_info['nodes_updated']}")
    click.echo(f"  Nodes deleted:  {status_info['nodes_deleted']}")


@cli.command()
@click.argument('query')
@click.option('--db', 'db_string',
              default='postgresql://localhost/tanachat',
              help='PostgreSQL connection string')
@click.option('--limit', default=10, help='Max results')
def search(query: str, db_string: str, limit: int):
    """Search nodes by text"""
    
    queries = TanaQueries(db_string)
    results = queries.search_full_text(query, limit)
    
    if not results:
        click.echo(click.style("No results found", fg='yellow'))
        return
    
    click.echo(click.style(f"Found {len(results)} results:", fg='green'))
    for result in results:
        click.echo(f"\n  {result['id']}: {result['name']}")
        if result['description']:
            click.echo(f"    {result['description'][:100]}")


@cli.command()
@click.option('--db', 'db_string',
              default='postgresql://localhost/tanachat',
              help='PostgreSQL connection string')
def init_db(db_string: str):
    """Initialize database schema"""
    
    import psycopg2
    
    # Read schema SQL
    schema_path = Path(__file__).parent.parent / 'schema.sql'
    
    if not schema_path.exists():
        click.echo(click.style("✗ schema.sql not found", fg='red'))
        raise click.Abort()
    
    with open(schema_path, 'r') as f:
        schema_sql = f.read()
    
    # Execute schema
    conn = psycopg2.connect(db_string)
    with conn.cursor() as cur:
        cur.execute(schema_sql)
    conn.commit()
    conn.close()
    
    click.echo(click.style("✓ Database initialized", fg='green'))


if __name__ == '__main__':
    cli()
```

---

## Configuration

### config.yaml

```yaml
# TanaChat Configuration

database:
  connection_string: "postgresql://localhost:5432/tanachat"
  pool_size: 10
  pool_timeout: 30

sync:
  # Default sync mode: incremental | full
  default_mode: "incremental"
  
  # Export directory
  export_dir: "/home/tom/tana-exports"
  
  # Archive settings
  archive_days: 30  # Keep exports for 30 days
  
  # Batch sizes
  batch_size: 1000

mcp:
  # Server settings
  host: "0.0.0.0"
  port: 8000
  
  # Query limits
  default_limit: 20
  max_limit: 100

logging:
  level: "INFO"
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  file: "/var/log/tanachat/tanachat.log"
```

---

## Deployment

### requirements.txt

```
# Core dependencies
psycopg2-binary==2.9.9
fastmcp==0.2.0
click==8.1.7
pyyaml==6.0.1

# Optional: for enhanced features
sqlalchemy==2.0.23  # If you want ORM capabilities
alembic==1.13.0     # For database migrations
rich==13.7.0        # For better CLI output
```

### Installation Script

```bash
#!/bin/bash
# install.sh

set -e

echo "Installing TanaChat..."

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Initialize database
echo "Enter PostgreSQL connection string:"
read -r DB_STRING

# Create database if it doesn't exist
createdb tanachat 2>/dev/null || true

# Initialize schema
python -m cli.main init-db --db "$DB_STRING"

echo "✓ Installation complete"
echo ""
echo "Next steps:"
echo "1. Export your Tana workspace to JSON"
echo "2. Run: python -m cli.main sync <export-file>"
echo "3. Start MCP server: python -m mcp_server.server"
```

### Cron Job Setup

```bash
#!/bin/bash
# setup-cron.sh

# Daily sync at 2 AM
CRON_JOB="0 2 * * * cd /home/tom/tanachat && ./sync-daily.sh >> /var/log/tanachat/cron.log 2>&1"

# Add to crontab
(crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -

echo "✓ Cron job installed"
```

### Daily Sync Script

```bash
#!/bin/bash
# sync-daily.sh

set -e

EXPORT_DIR="/home/tom/tana-exports"
DB_STRING="postgresql://localhost/tanachat"
VENV_PATH="/home/tom/tanachat/venv"

# Activate virtual environment
source "$VENV_PATH/bin/activate"

# Find most recent export
LATEST_EXPORT=$(ls -t "$EXPORT_DIR"/tana-*.json 2>/dev/null | head -1)

if [ -z "$LATEST_EXPORT" ]; then
    echo "No export files found in $EXPORT_DIR"
    exit 1
fi

echo "Syncing export: $LATEST_EXPORT"

# Run sync
python -m cli.main sync "$LATEST_EXPORT" --db "$DB_STRING" --mode incremental

# Clean up old exports (keep 7 days)
find "$EXPORT_DIR" -name "tana-*.json" -mtime +7 -delete

echo "✓ Daily sync complete"
```

---

## Testing Strategy

### Test Structure

```python
# tests/test_sync.py

import pytest
from pathlib import Path
from sync_engine.sync import SyncEngine


@pytest.fixture
def test_db():
    """Create test database"""
    conn_string = "postgresql://localhost/tanachat_test"
    # Setup and teardown logic
    yield conn_string


@pytest.fixture
def sample_export(tmp_path):
    """Create sample Tana export"""
    export = {
        "lastTxid": 1234567890,
        "formatVersion": 1,
        "docs": [
            {
                "id": "TEST_01",
                "props": {
                    "name": "Test Node",
                    "_docType": "tagDef",
                    "created": 1234567890
                }
            }
        ]
    }
    
    export_path = tmp_path / "test-export.json"
    import json
    with open(export_path, 'w') as f:
        json.dump(export, f)
    
    return export_path


def test_incremental_sync(test_db, sample_export):
    """Test incremental sync"""
    engine = SyncEngine(test_db)
    
    # First sync
    stats1 = engine.sync_export(sample_export, mode='incremental')
    assert stats1['nodes_added'] == 1
    assert stats1['nodes_updated'] == 0
    
    # Second sync (no changes)
    stats2 = engine.sync_export(sample_export, mode='incremental')
    assert stats2['nodes_added'] == 0
    assert stats2['nodes_unchanged'] == 1


def test_change_detection(test_db, sample_export):
    """Test that changes are detected"""
    # Test implementation
    pass


def test_deletion_detection(test_db, sample_export):
    """Test that deleted nodes are marked"""
    # Test implementation
    pass
```

---

## Migration Plan

### Phase 1: Foundation (Week 1)
- ✓ Set up PostgreSQL database
- ✓ Implement schema
- ✓ Create sync engine (basic)
- ✓ Test with sample exports

### Phase 2: Core Sync (Week 2)
- ✓ Implement incremental sync
- ✓ Add change detection
- ✓ Create CLI tools
- ✓ Set up daily cron job

### Phase 3: MCP Server (Week 3)
- ✓ Implement FastMCP server
- ✓ Create core query tools
- ✓ Add full-text search
- ✓ Test with Claude Desktop

### Phase 4: Enhancement (Week 4)
- ✓ Add advanced queries
- ✓ Performance optimization
- ✓ Documentation
- ✓ Deploy to production

---

## Performance Targets

- **Sync Performance:**
  - Small export (<1000 nodes): < 5 seconds
  - Medium export (1000-10000 nodes): < 30 seconds
  - Large export (>10000 nodes): < 2 minutes

- **Query Performance:**
  - Node by ID: < 10ms
  - Full-text search: < 100ms
  - Hierarchy traversal (3 levels): < 200ms

- **MCP Response Time:**
  - Simple queries: < 500ms
  - Complex queries: < 2 seconds

---

## Monitoring & Observability

### Key Metrics to Track

1. **Sync Metrics:**
   - Sync frequency
   - Sync duration
   - Nodes added/updated/deleted per sync
   - Error rate

2. **Query Metrics:**
   - Query response times
   - Query frequency by tool
   - Error rates

3. **Database Metrics:**
   - Database size
   - Index usage
   - Slow queries

### Logging Strategy

```python
# Example logging configuration
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/var/log/tanachat/app.log'),
        logging.StreamHandler()
    ]
)

# Add structured logging for metrics
import json

def log_sync_metrics(stats):
    metrics = {
        'event': 'sync_complete',
        'timestamp': datetime.now().isoformat(),
        **stats
    }
    logger.info(json.dumps(metrics))
```

---

## Security Considerations

1. **Database Access:**
   - Use connection pooling
   - Implement read-only user for MCP queries
   - Encrypt connection strings in config

2. **Export Files:**
   - Validate export structure before processing
   - Sanitize file paths
   - Implement file size limits

3. **MCP Server:**
   - Rate limiting on queries
   - Input validation
   - SQL injection prevention (use parameterized queries)

---

## Future Enhancements

1. **Real-time Sync:**
   - Monitor Tana export directory for changes
   - Auto-trigger sync on new exports

2. **Multi-workspace Support:**
   - Support multiple Tana workspaces
   - Workspace-level isolation

3. **Advanced Queries:**
   - Graph traversal queries
   - Temporal queries (view data as of specific date)
   - Custom field indexing

4. **Export Integration:**
   - Auto-export from Tana (if API becomes available)
   - Two-way sync (write back to Tana)

5. **Analytics:**
   - Usage dashboards
   - Knowledge graph visualization
   - Productivity insights

---

## Conclusion

This specification provides a complete roadmap for upgrading TanaChat to a production-ready system with:
- Robust PostgreSQL backend
- Incremental sync with change detection
- Comprehensive MCP tooling
- CLI for management
- Monitoring and observability

The architecture is designed for reliability, performance, and future extensibility.

**Next Steps:**
1. Review and validate schema design
2. Implement Phase 1 (database setup)
3. Test with your actual Tana exports
4. Iterate based on real-world usage patterns

---

**Document Version:** 1.0  
**Last Updated:** December 2024  
**Contact:** tom@tomhaus.com
