# TanaChat Upgrade - Quick Start Guide

## Prerequisites

- PostgreSQL 14+ installed
- Python 3.9+
- Tana export file (JSON format)
- Basic familiarity with command line

## Quick Setup (30 minutes)

### 1. Database Setup

```bash
# Create database
createdb tanachat

# Initialize schema
psql tanachat < schema.sql
```

### 2. Python Environment

```bash
# Create project directory
mkdir -p ~/tanachat
cd ~/tanachat

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install psycopg2-binary fastmcp click pyyaml
```

### 3. Create Minimal Sync Script

Save as `sync.py`:

```python
#!/usr/bin/env python3
"""Minimal Tana sync script"""

import json
import hashlib
import sys
from datetime import datetime
import psycopg2
from psycopg2.extras import Json, execute_values

DB_CONN = "postgresql://localhost/tanachat"

def calculate_hash(doc):
    """Calculate content hash"""
    normalized = {
        'id': doc['id'],
        'props': doc.get('props', {}),
        'children': doc.get('children', [])
    }
    content_json = json.dumps(normalized, sort_keys=True)
    return hashlib.sha256(content_json.encode()).hexdigest()

def sync_export(export_path):
    """Sync Tana export"""
    print(f"Loading {export_path}...")
    
    with open(export_path, 'r') as f:
        data = json.load(f)
    
    export_txid = data['lastTxid']
    docs = data['docs']
    
    print(f"Processing {len(docs)} documents...")
    
    conn = psycopg2.connect(DB_CONN)
    cur = conn.cursor()
    
    # Get last sync
    cur.execute("SELECT MAX(export_txid) FROM sync_log")
    last_txid = cur.fetchone()[0] or 0
    
    if export_txid <= last_txid:
        print(f"⚠ Export not newer than last sync ({last_txid})")
        return
    
    added = updated = unchanged = 0
    current_ids = set()
    
    # Process each document
    for doc in docs:
        node_id = doc['id']
        current_ids.add(node_id)
        props = doc.get('props', {})
        content_hash = calculate_hash(doc)
        
        # Check if exists
        cur.execute("SELECT sync_hash FROM nodes WHERE id = %s", (node_id,))
        existing = cur.fetchone()
        
        if not existing:
            # Insert new
            cur.execute("""
                INSERT INTO nodes (
                    id, doc_type, name, description, owner_id,
                    meta_node_id, source_id, created, props,
                    modified_ts, touch_counts, last_seen_txid, sync_hash
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                node_id,
                props.get('_docType'),
                props.get('name'),
                props.get('description'),
                props.get('_ownerId'),
                props.get('_metaNodeId'),
                props.get('_sourceId'),
                props.get('created'),
                Json(props),
                Json(doc.get('modifiedTs', {})),
                Json(doc.get('touchCounts', {})),
                export_txid,
                content_hash
            ))
            
            # Insert children
            if 'children' in doc:
                children_values = [
                    (node_id, child_id, pos)
                    for pos, child_id in enumerate(doc['children'])
                ]
                execute_values(cur, """
                    INSERT INTO node_children (parent_id, child_id, position)
                    VALUES %s
                    ON CONFLICT DO NOTHING
                """, children_values)
            
            added += 1
            
        elif existing[0] != content_hash:
            # Update changed
            cur.execute("""
                UPDATE nodes SET
                    doc_type = %s, name = %s, description = %s,
                    owner_id = %s, meta_node_id = %s, source_id = %s,
                    props = %s, modified_ts = %s, touch_counts = %s,
                    last_seen_txid = %s, sync_hash = %s,
                    last_synced_at = NOW()
                WHERE id = %s
            """, (
                props.get('_docType'), props.get('name'), props.get('description'),
                props.get('_ownerId'), props.get('_metaNodeId'), props.get('_sourceId'),
                Json(props), Json(doc.get('modifiedTs', {})), Json(doc.get('touchCounts', {})),
                export_txid, content_hash, node_id
            ))
            
            # Update children
            cur.execute("DELETE FROM node_children WHERE parent_id = %s", (node_id,))
            if 'children' in doc:
                children_values = [
                    (node_id, child_id, pos)
                    for pos, child_id in enumerate(doc['children'])
                ]
                execute_values(cur, """
                    INSERT INTO node_children (parent_id, child_id, position)
                    VALUES %s
                """, children_values)
            
            updated += 1
        else:
            # Unchanged - just touch
            cur.execute(
                "UPDATE nodes SET last_seen_txid = %s WHERE id = %s",
                (export_txid, node_id)
            )
            unchanged += 1
    
    # Mark deleted
    cur.execute("""
        UPDATE nodes SET is_deleted = TRUE
        WHERE last_seen_txid < %s AND is_deleted = FALSE
    """, (export_txid,))
    deleted = cur.rowcount
    
    # Log sync
    cur.execute("""
        INSERT INTO sync_log (
            export_txid, export_filename,
            nodes_added, nodes_updated, nodes_deleted, nodes_unchanged
        ) VALUES (%s, %s, %s, %s, %s, %s)
    """, (export_txid, export_path, added, updated, deleted, unchanged))
    
    conn.commit()
    cur.close()
    conn.close()
    
    print(f"✓ Sync complete:")
    print(f"  Added:     {added}")
    print(f"  Updated:   {updated}")
    print(f"  Deleted:   {deleted}")
    print(f"  Unchanged: {unchanged}")

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: python sync.py <export-file.json>")
        sys.exit(1)
    
    sync_export(sys.argv[1])
```

Make it executable:
```bash
chmod +x sync.py
```

### 4. Create Minimal MCP Server

Save as `mcp_server.py`:

```python
#!/usr/bin/env python3
"""Minimal TanaChat MCP Server"""

from mcp import FastMCP
import psycopg2
from psycopg2.extras import RealDictCursor

DB_CONN = "postgresql://localhost/tanachat"

mcp = FastMCP("TanaChat")

def get_conn():
    return psycopg2.connect(DB_CONN)

@mcp.tool()
def search_nodes(query: str, limit: int = 10) -> list:
    """Search nodes by name or description"""
    conn = get_conn()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    
    cur.execute("""
        SELECT id, name, description, doc_type, created
        FROM nodes
        WHERE (name ILIKE %s OR description ILIKE %s)
          AND is_deleted = FALSE
        ORDER BY created DESC
        LIMIT %s
    """, (f'%{query}%', f'%{query}%', limit))
    
    results = [dict(row) for row in cur.fetchall()]
    cur.close()
    conn.close()
    return results

@mcp.tool()
def get_node(node_id: str) -> dict:
    """Get a specific node by ID"""
    conn = get_conn()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    
    cur.execute("""
        SELECT n.*,
               ARRAY_AGG(nc.child_id ORDER BY nc.position) 
                   FILTER (WHERE nc.child_id IS NOT NULL) as children
        FROM nodes n
        LEFT JOIN node_children nc ON n.id = nc.parent_id
        WHERE n.id = %s AND n.is_deleted = FALSE
        GROUP BY n.id
    """, (node_id,))
    
    result = cur.fetchone()
    cur.close()
    conn.close()
    return dict(result) if result else None

@mcp.tool()
def list_supertags() -> list:
    """List all supertags"""
    conn = get_conn()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    
    cur.execute("""
        SELECT id, name, description, doc_type
        FROM nodes
        WHERE doc_type = 'tagDef' AND is_deleted = FALSE
        ORDER BY name
    """)
    
    results = [dict(row) for row in cur.fetchall()]
    cur.close()
    conn.close()
    return results

@mcp.tool()
def get_sync_status() -> dict:
    """Get last sync status"""
    conn = get_conn()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    
    cur.execute("""
        SELECT * FROM sync_log
        ORDER BY synced_at DESC
        LIMIT 1
    """)
    
    result = cur.fetchone()
    cur.close()
    conn.close()
    return dict(result) if result else {'status': 'no_sync_yet'}

if __name__ == '__main__':
    mcp.run()
```

Make it executable:
```bash
chmod +x mcp_server.py
```

### 5. First Sync

```bash
# Export from Tana (manual step in Tana UI)
# Then sync to database:
python sync.py ~/Downloads/tana-export.json
```

### 6. Configure Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "tanachat": {
      "command": "/Users/tom/tanachat/venv/bin/python",
      "args": ["/Users/tom/tanachat/mcp_server.py"]
    }
  }
}
```

Restart Claude Desktop.

### 7. Test MCP Server

In Claude Desktop:
```
Can you search my Tana for nodes about "AI"?
```

## Daily Sync Setup

Create `~/tanachat/sync-daily.sh`:

```bash
#!/bin/bash
set -e

EXPORT_DIR="$HOME/tana-exports"
TANACHAT_DIR="$HOME/tanachat"

cd "$TANACHAT_DIR"
source venv/bin/activate

# Find most recent export
LATEST=$(ls -t "$EXPORT_DIR"/tana-*.json 2>/dev/null | head -1)

if [ -z "$LATEST" ]; then
    echo "No exports found in $EXPORT_DIR"
    exit 1
fi

echo "Syncing: $LATEST"
python sync.py "$LATEST"

# Cleanup old exports (keep 7 days)
find "$EXPORT_DIR" -name "tana-*.json" -mtime +7 -delete
```

Make executable:
```bash
chmod +x ~/tanachat/sync-daily.sh
```

Add to crontab (runs at 2 AM daily):
```bash
crontab -e
# Add this line:
0 2 * * * /Users/tom/tanachat/sync-daily.sh >> /tmp/tanachat-sync.log 2>&1
```

## Verify Everything Works

```bash
# 1. Check database has data
psql tanachat -c "SELECT COUNT(*) FROM nodes;"

# 2. Check sync log
psql tanachat -c "SELECT * FROM sync_log ORDER BY synced_at DESC LIMIT 1;"

# 3. Test search
psql tanachat -c "SELECT id, name FROM nodes WHERE name ILIKE '%test%' LIMIT 5;"

# 4. Test MCP server standalone
python mcp_server.py
# In another terminal:
# echo '{"method": "tools/list"}' | nc localhost 8000
```

## Common Issues

### Issue: Foreign key violations
**Solution:** Disable foreign key checks temporarily during first sync:
```sql
ALTER TABLE nodes DROP CONSTRAINT IF EXISTS fk_owner;
ALTER TABLE nodes DROP CONSTRAINT IF EXISTS fk_meta;
ALTER TABLE nodes DROP CONSTRAINT IF EXISTS fk_source;
-- Run sync, then re-add constraints
```

### Issue: Slow queries
**Solution:** Ensure indexes are created:
```bash
psql tanachat -c "SELECT * FROM pg_indexes WHERE tablename = 'nodes';"
```

### Issue: MCP server not showing in Claude
**Solution:** Check Claude Desktop logs:
```bash
tail -f ~/Library/Logs/Claude/mcp*.log
```

## Next Steps

Once basics work:

1. **Add more MCP tools** - Implement hierarchy traversal, field queries
2. **Optimize sync** - Batch processing, parallel inserts
3. **Add monitoring** - Track query performance, sync metrics
4. **Enhance search** - Add full-text search with ranking
5. **Build UI** - Optional web dashboard for browsing Tana data

## File Structure Summary

```
~/tanachat/
├── venv/                   # Python virtual environment
├── sync.py                 # Sync script (180 lines)
├── mcp_server.py           # MCP server (80 lines)
├── sync-daily.sh           # Daily cron job
└── schema.sql              # Database schema

~/tana-exports/             # Tana export storage
└── tana-2024-12-10.json

~/Library/Application Support/Claude/
└── claude_desktop_config.json  # MCP configuration
```

## Help & Support

- PostgreSQL docs: https://www.postgresql.org/docs/
- FastMCP docs: https://github.com/modelcontextprotocol/python-sdk
- Tana export format: Check your export JSON structure

---

**Total Setup Time:** ~30 minutes  
**Maintenance:** ~5 minutes/week (manual exports until API available)  
**Benefit:** Query your entire Tana workspace via Claude!
